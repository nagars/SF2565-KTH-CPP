Assignment is split into a folder for each problem.

Compiler used: MingGW / GCC
IDE: CodeBlocks / Eclipse IDE

To compile, use the command
g++ main.cpp -o main adaptive_integration.cpp
